
// This file re-exports the HomePage component
import HomePage from "./HomePage";

export default HomePage;
